package com.example.stockproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bnv;
    Fragment_main fragment_main; //메인
    Fragment_Predict fragment_predict; // 각 주가 정보 -> 주가 예측
    Fragment_information fragment_information; // 시장정보
    Fragment_learn fragment_learn; //주식용어
    Fragment_myPage fragment_myPage; // 잔고

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 메뉴는 findViewByid 한다.
        bnv = findViewById(R.id.bottombar);

        // Fragment들은 객체 생성한다
        fragment_information = new Fragment_information();
        fragment_learn = new Fragment_learn();
        fragment_main = new Fragment_main();
        fragment_myPage = new Fragment_myPage();
        fragment_predict = new Fragment_Predict();

        // bottomNavigationBar에서 어떤 메뉴가 선택됐는지 확인
        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                // 매개변수 item => 내가 선택한 메뉴
                switch (item.getItemId()){ 
                    case R.id.tab1: 
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container,fragment_main).commit();
                        // R.id.container 자리에 fragment1을 끼우겠다
                        break;
                    case R.id.tab2: 
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container,fragment_predict).commit();
                        break;
                    case R.id.tab3: 
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container,fragment_information).commit();
                        break;
                    case R.id.tab4: 
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container,fragment_learn).commit();
                        break;
                    case R.id.tab5: 
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container,fragment_myPage).commit();
                        break;
                }

                return true; 
            }
        });
    }
}