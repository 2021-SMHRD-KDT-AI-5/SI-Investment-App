package com.example.stockproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Fragment_login extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // view에 저장 -> 찾고싶은데 생기면 view에서 가져오면 됨
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // WebView를 찾아서 WebView 객체에 저장하기
        WebView wb = view.findViewById(R.id.webview);

        // webview 설정하기
        // 1. url 저장
        String address = "http://172.30.1.37:8089/3rdProejct2/pages/Login.jsp";

        // 2. 자바 스크립트 활성화
        WebSettings webSettings = wb.getSettings(); //setting할 수 있는 객체 가져옴
        webSettings.setJavaScriptEnabled(true);

        // 3. 설정 적용!
        wb.loadUrl(address);
        wb.setWebViewClient(new WebViewClient());

        // 4. http 통신규약 옵션 설정하기
        // manifests 파일 열어서 코드 추가


        return view;
    }
}